<?php
/**
& author:david
* site:http://spetacular.github.io/
* weibo:http://weibo.com/mylxq
* twitter:https://twitter.com/butbits
*/
$text = '日前，奥迪全新SQ7运动版车型的无伪装谍照出人意料的被曝光出来，该车预计今年底或者明年初发布。可以看到，新车已经有一些专属设计明显的区别于普通版的车型。';
$file = './dict.txt';

$obj = new MaxWordSegmentation($file);
$ret = $obj->run($text);
var_dump($ret);


class MaxWordSegmentation{

	private $dict = array();//保存字典的list

	function __construct($pathToDict){
		$this->dict = $this->loadDict($pathToDict);
	}
	
	//读入词典文件到内存
	function loadDict($pathToDict){
		if(!file_exists($pathToDict)){
			die('Can not find dict file!');
		}
		$dicts = array();
		$handle = @fopen($pathToDict, "r");
		if ($handle) {
			while (!feof($handle)) {
				$word = fgets($handle, 4096);
				//这里的词需要用trim去掉换行符
				$word = trim($word);
				$dicts[$word] = 1;
			}
			fclose($handle);
		}
		return $dicts;
	}

	//查看词是否在字典中
	function inDict($word){
		return array_key_exists($word,$this->dict);
	}

	//按照词典进行分词。正向最大匹配法
	function run($text,$encode = 'utf-8'){
		$minLen = 0;
		$maxLen = 0;
		//找出最长的单词长度及最短的单词长度
		foreach($this->dict as $key=>$value){
			$iLen = mb_strlen($key,$encode);
			if($minLen > $iLen || $minLen == 0 ){
				$minLen = $iLen;
			}

			if($maxLen < $iLen){
				$maxLen = $iLen;
			}
		}
		

		$sLen = mb_strlen($text, $encode);
		$result = array();
		for($start = 0;$start < $sLen;$start ++){	
			for($maxLoop = $maxLen;$maxLoop >= $minLen;$maxLoop --){
				$word = mb_substr ($text , $start, $maxLoop , $encode);
				//是否匹配成功
				if($this->inDict($word,$this->dict)){
					//添加到输出列表
					if(!in_array($word,$result)){
						$result[] = $word;
					}
					break;
				}
			}
			
			
		}
		return $result;
	}
}


?>